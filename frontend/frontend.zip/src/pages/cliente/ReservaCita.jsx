import { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
    Container, 
    Paper, 
    Stepper, 
    Step, 
    StepLabel, 
    Box,
    Typography,
    Button
} from '@mui/material';
import { motion, AnimatePresence } from 'framer-motion';
import { useReserva } from '../../context/ReservaContext';
import PasoServicio from '../../components/reserva/PasoServicio';
import PasoPeluquero from '../../components/reserva/PasoPeluquero';
import PasoFechaHora from '../../components/reserva/PasoFechaHora';
import PasoConfirmacion from '../../components/reserva/PasoConfirmacion';

const pasos = [
    'Seleccionar Servicio',
    'Elegir Peluquero',
    'Fecha y Hora',
    'Confirmar'
];

const ReservaCita = () => {
    const { peluqueriaId } = useParams();
    const navigate = useNavigate();
    const { 
        pasoActual, 
        pasoAnterior, 
        siguientePaso,
        peluqueriaSeleccionada,
        setPeluqueriaSeleccionada
    } = useReserva();

    useEffect(() => {
        // Si viene de un marcador del mapa, establecer la peluquería
        if (peluqueriaId) {
            // Aquí deberías cargar los datos de la peluquería
            // Por ahora lo simulamos
            setPeluqueriaSeleccionada({ id: peluqueriaId });
        }
    }, [peluqueriaId, setPeluqueriaSeleccionada]);

    const renderPaso = () => {
        switch (pasoActual) {
            case 0:
                return <PasoServicio />;
            case 1:
                return <PasoPeluquero />;
            case 2:
                return <PasoFechaHora />;
            case 3:
                return <PasoConfirmacion />;
            default:
                return null;
        }
    };

    return (
        <Box sx={{
            backgroundColor: '#f5f5f5', // Fondo gris claro
            minHeight: '100vh', // Ocupar toda la altura de la pantalla
            display: 'flex',
            justifyContent: 'center', // Centrar horizontalmente
            alignItems: 'center', // Centrar verticalmente
            py: 4, // Padding vertical
        }}>
            <Container maxWidth="lg">
                <Paper sx={{ p: 3, mb: 3 }}>
                    <Typography variant="h4" gutterBottom align="center">
                        Reserva tu Cita
                    </Typography>
                    
                    <Stepper activeStep={pasoActual} alternativeLabel sx={{ mb: 4 }}>
                        {pasos.map((label) => (
                            <Step key={label} completed={pasoActual > pasos.indexOf(label)}>
                                <StepLabel
                                    StepIconProps={{
                                        sx: {
                                            '&.Mui-completed': {
                                                color: '#d72a3c',
                                            },
                                            '&.Mui-active': {
                                                color: '#d72a3c',
                                            },
                                            color: pasoActual >= pasos.indexOf(label) ? '#d72a3c' : undefined,
                                        },
                                    }}
                                >
                                    {label}
                                </StepLabel>
                            </Step>
                        ))}
                    </Stepper>

                    <AnimatePresence mode="wait">
                        <motion.div
                            key={pasoActual}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                            transition={{ duration: 0.3 }}
                        >
                            {renderPaso()}
                        </motion.div>
                    </AnimatePresence>

                    {pasoActual < 3 && (
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
                            <Button
                                variant="outlined"
                                onClick={() => navigate('/cliente/mapa')}
                                sx={{
                                    color: '#d72a3c',
                                    borderColor: '#d72a3c',
                                    '&:hover': {
                                        borderColor: '#c02534',
                                        backgroundColor: 'rgba(215, 42, 60, 0.04)',
                                    },
                                }}
                            >
                                Cancelar
                            </Button>
                            <Box>
                                {pasoActual > 0 && (
                                    <Button
                                        variant="outlined"
                                        onClick={pasoAnterior}
                                        sx={{
                                            mr: 1,
                                            color: '#d72a3c',
                                            borderColor: '#d72a3c',
                                            '&:hover': {
                                                borderColor: '#c02534',
                                                backgroundColor: 'rgba(215, 42, 60, 0.04)',
                                            },
                                        }}
                                    >
                                        Anterior
                                    </Button>
                                )}
                                <Button
                                    variant="contained"
                                    onClick={siguientePaso}
                                    disabled={pasoActual === 0 && !peluqueriaSeleccionada ||
                                        (pasoActual === 1 && !peluqueriaSeleccionada) ||
                                        (pasoActual === 2 && !peluqueriaSeleccionada)
                                    }
                                    sx={{
                                        backgroundColor: '#d72a3c',
                                        '&:hover': {
                                            backgroundColor: '#c02534',
                                        },
                                    }}
                                >
                                    {pasoActual === pasos.length - 2 ? 'Confirmar' : 'Siguiente'}
                                </Button>
                            </Box>
                        </Box>
                    )}
                </Paper>
            </Container>
        </Box>
    );
};

export default ReservaCita; 