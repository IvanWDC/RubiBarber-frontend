import axios from 'axios';

const API_URL = 'http://localhost:8080/api';

// Configurar axios para incluir el token en todas las peticiones
axios.interceptors.request.use(config => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

export const reservaService = {
    // Obtener servicios disponibles
    getServicios: async () => {
        try {
            const response = await axios.get(`${API_URL}/cliente/servicios`);
            return response.data;
        } catch (error) {
            console.error('Error al obtener servicios:', error);
            throw new Error('No se pudieron cargar los servicios');
        }
    },

    // Obtener peluqueros de una peluquería
    getPeluquerosByPeluqueria: async (peluqueriaId) => {
        try {
            const response = await axios.get(`${API_URL}/peluquerias/${peluqueriaId}/peluqueros`);
            return response.data.filter(p => p.activo); // Solo peluqueros activos
        } catch (error) {
            console.error('Error al obtener peluqueros:', error);
            throw new Error('No se pudieron cargar los peluqueros');
        }
    },

    // Obtener horarios disponibles de un peluquero
    getHorariosDisponibles: async (peluqueroId, fecha) => {
        try {
            const response = await axios.get(
                `${API_URL}/horarios/peluquero/${peluqueroId}?fecha=${fecha}`
            );
            return response.data;
        } catch (error) {
            console.error('Error al obtener horarios:', error);
            throw new Error('No se pudieron cargar los horarios disponibles');
        }
    },

    // Crear una nueva cita
    crearCita: async (usuarioId, servicioId, peluqueroId, fechaHora) => {
        try {
            const response = await axios.post(
                `${API_URL}/citas/${usuarioId}/${servicioId}/${peluqueroId}`,
                { fechaHora }
            );
            return response.data;
        } catch (error) {
            if (error.response?.status === 409) {
                throw new Error('El peluquero ya tiene una cita en ese horario');
            }
            console.error('Error al crear cita:', error);
            throw new Error('No se pudo crear la cita');
        }
    },

    // Obtener detalles de una peluquería
    getPeluqueriaById: async (peluqueriaId) => {
        try {
            const response = await axios.get(`${API_URL}/peluquerias/${peluqueriaId}`);
            return response.data;
        } catch (error) {
            console.error('Error al obtener detalles de la peluquería:', error);
            throw new Error('No se pudieron cargar los detalles de la peluquería');
        }
    }
}; 