import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import PrivateRoute from './components/PrivateRoute';
import DashboardCliente from './pages/DashboardCliente';
import MisCitasCliente from './pages/MisCitasCliente';
import MapaPeluquerias from './pages/MapaPeluquerias';
import ReservaCita from './pages/cliente/ReservaCita';
import { ReservaProvider } from './context/ReservaContext';

const DummyPage = ({ title }) => <h2>{title}</h2>;

function App() {
  return (
    <ReservaProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/registro" element={<RegisterPage />} />

          {/* Cliente */}
          <Route
            path="/cliente"
            element={
              <PrivateRoute requiredRole="CLIENTE">
                <DashboardCliente />
              </PrivateRoute>
            }
          />
          <Route
            path="/cliente/miscitas"
            element={
              <PrivateRoute requiredRole="CLIENTE">
                <MisCitasCliente />
              </PrivateRoute>
            }
          />
          <Route
            path="/cliente/mapa"
            element={
              <PrivateRoute requiredRole="CLIENTE">
                <MapaPeluquerias />
              </PrivateRoute>
            }
          />
          <Route
            path="/cliente/reserva/:peluqueriaId?"
            element={
              <PrivateRoute requiredRole="CLIENTE">
                <ReservaCita />
              </PrivateRoute>
            }
          />
          <Route
            path="/cliente/peluquerias-por-servicio/:idServicio"
            element={
              <PrivateRoute requiredRole="CLIENTE">
                <MapaPeluquerias />
              </PrivateRoute>
            }
          />

          {/* Peluquero */}
          <Route
            path="/peluquero"
            element={
              <PrivateRoute requiredRole="PELUQUERO">
                <DummyPage title="Dashboard Peluquero" />
              </PrivateRoute>
            }
          />

          {/* Admin */}
          <Route
            path="/admin"
            element={
              <PrivateRoute requiredRole="ADMIN">
                <DummyPage title="Dashboard Admin" />
              </PrivateRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </ReservaProvider>
  );
}

export default App;
